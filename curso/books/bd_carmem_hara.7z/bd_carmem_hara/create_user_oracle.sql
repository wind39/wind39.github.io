create user curso identified by 12345
default tablespace users
temporary tablespace temp
quota unlimited on users;

grant all privileges to curso;